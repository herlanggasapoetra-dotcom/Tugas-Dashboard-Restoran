"""API Dashboard Restoran - Bahan Baku Dapur (FastAPI).

Data disimpan di list Python (in-memory) dan setiap perubahan
(tambah/ubah/hapus) ditulis ulang ke data.json, jadi data tidak hilang
saat server di-restart. Tidak memakai database.
"""
import json
import os
import threading
from pathlib import Path
from typing import List, Optional

from fastapi import FastAPI, HTTPException, Response, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, field_validator

DATA_FILE = Path(__file__).parent / "data.json"
lock = threading.Lock()


# ---------- Skema Pydantic ----------
class BahanBakuBase(BaseModel):
    nama_bahan: str = Field(..., min_length=1, max_length=100, description="Nama bahan baku")
    kategori: str = Field(..., min_length=1, max_length=50, description="Kategori, mis. Sayuran, Daging")
    stok: float = Field(..., ge=0, description="Jumlah stok (angka, tidak boleh negatif)")
    satuan: str = Field(..., min_length=1, max_length=20, description="Satuan, mis. kg, liter, butir")

    @field_validator("nama_bahan", "kategori", "satuan")
    @classmethod
    def tidak_boleh_kosong(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("tidak boleh kosong")
        return v


class BahanBakuCreate(BahanBakuBase):
    """Body untuk POST dan PUT."""


class BahanBakuUpdate(BaseModel):
    """Body untuk PATCH: semua field opsional."""
    nama_bahan: Optional[str] = Field(None, min_length=1, max_length=100)
    kategori: Optional[str] = Field(None, min_length=1, max_length=50)
    stok: Optional[float] = Field(None, ge=0)
    satuan: Optional[str] = Field(None, min_length=1, max_length=20)


class BahanBaku(BahanBakuBase):
    id: int = Field(..., description="ID unik, dibuat otomatis oleh server")


# ---------- Penyimpanan JSON ----------
def muat_data() -> List[dict]:
    if not DATA_FILE.exists():
        return []
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def simpan_data() -> None:
    """Menimpa (overwrite) data.json dengan isi list saat ini."""
    tmp = DATA_FILE.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(bahan_list, f, indent=2, ensure_ascii=False)
    os.replace(tmp, DATA_FILE)


bahan_list: List[dict] = muat_data()


def cari_index(item_id: int) -> int:
    for i, b in enumerate(bahan_list):
        if b["id"] == item_id:
            return i
    raise HTTPException(status_code=404, detail=f"Bahan baku dengan id {item_id} tidak ditemukan")


# ---------- Aplikasi ----------
app = FastAPI(
    title="API Bahan Baku Dapur",
    description="Backend mini dashboard restoran: kelola stok bahan baku dapur. "
                "Data disimpan di file JSON lokal (tanpa database).",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/bahan-baku", response_model=List[BahanBaku], tags=["Bahan Baku"],
         summary="Ambil semua bahan baku")
def ambil_semua():
    """Mengembalikan seluruh daftar bahan baku."""
    return bahan_list


@app.get("/bahan-baku/{item_id}", response_model=BahanBaku, tags=["Bahan Baku"],
         summary="Ambil satu bahan baku")
def ambil_satu(item_id: int):
    """Mengembalikan satu bahan baku berdasarkan id. 404 jika tidak ada."""
    return bahan_list[cari_index(item_id)]


@app.post("/bahan-baku", response_model=BahanBaku, status_code=status.HTTP_201_CREATED,
          tags=["Bahan Baku"], summary="Tambah bahan baku baru")
def tambah(body: BahanBakuCreate):
    """Menambah bahan baku. `id` dibuat otomatis. Stok harus angka >= 0."""
    with lock:
        new_id = max((b["id"] for b in bahan_list), default=0) + 1
        item = {"id": new_id, **body.model_dump()}
        bahan_list.append(item)
        simpan_data()
    return item


@app.put("/bahan-baku/{item_id}", response_model=BahanBaku, tags=["Bahan Baku"],
         summary="Ubah seluruh data bahan baku")
def ganti(item_id: int, body: BahanBakuCreate):
    """Mengganti semua field bahan baku (nama, kategori, stok, satuan)."""
    with lock:
        i = cari_index(item_id)
        bahan_list[i] = {"id": item_id, **body.model_dump()}
        simpan_data()
        return bahan_list[i]


@app.patch("/bahan-baku/{item_id}", response_model=BahanBaku, tags=["Bahan Baku"],
           summary="Ubah sebagian data (mis. update stok)")
def ubah_sebagian(item_id: int, body: BahanBakuUpdate):
    """Mengubah hanya field yang dikirim, misalnya `{"stok": 10}`."""
    with lock:
        i = cari_index(item_id)
        bahan_list[i].update(body.model_dump(exclude_unset=True, exclude_none=True))
        simpan_data()
        return bahan_list[i]


@app.delete("/bahan-baku/{item_id}", status_code=status.HTTP_204_NO_CONTENT,
            tags=["Bahan Baku"], summary="Hapus bahan baku")
def hapus(item_id: int):
    """Menghapus bahan baku berdasarkan id. 404 jika tidak ada."""
    with lock:
        i = cari_index(item_id)
        bahan_list.pop(i)
        simpan_data()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
