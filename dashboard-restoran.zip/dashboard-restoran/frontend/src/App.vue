<script setup>
import { ref, computed, onMounted } from 'vue'

// ---------- Konfigurasi ----------
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'
const ENDPOINT = `${API_URL}/bahan-baku`
// Ambang batas status stok (dijelaskan di README):
// stok <= 0 -> Stok Habis, stok <= BATAS_MENIPIS -> Menipis, selebihnya Aman
const BATAS_MENIPIS = 5

// ---------- State (ref) ----------
const bahanList = ref([])
const loadState = ref('loading') // 'loading' | 'error' | 'success'
const loadError = ref('')
const notif = ref(null) // { tipe: 'ok' | 'gagal', teks }

const keyword = ref('')
const urutan = ref('asc') // 'asc' = A-Z, 'desc' = Z-A

const formTerbuka = ref(false)
const editId = ref(null)
const form = ref(formKosong())
const formError = ref('')
const menyimpan = ref(false)

function formKosong() {
  return { nama_bahan: '', kategori: '', stok: '', satuan: '' }
}

// ---------- Fetch helper (async/await + try/catch di pemanggil) ----------
async function request(url, options = {}) {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })
  if (!res.ok) {
    let pesan = `Server menjawab dengan kode ${res.status}`
    try {
      const body = await res.json()
      if (Array.isArray(body.detail)) {
        pesan = body.detail
          .map((d) => `${d.loc[d.loc.length - 1]}: ${d.msg}`)
          .join('; ')
      } else if (body.detail) {
        pesan = body.detail
      }
    } catch {
      /* body bukan JSON, pakai pesan bawaan */
    }
    throw new Error(pesan)
  }
  return res.status === 204 ? null : res.json()
}

async function muatData(tampilkanLoading = true) {
  if (tampilkanLoading) loadState.value = 'loading'
  try {
    bahanList.value = await request(ENDPOINT)
    loadState.value = 'success'
  } catch (err) {
    loadError.value =
      err instanceof TypeError
        ? 'Tidak bisa terhubung ke backend. Pastikan server FastAPI berjalan di ' + API_URL
        : err.message
    loadState.value = 'error'
  }
}

function tampilNotif(tipe, teks) {
  notif.value = { tipe, teks }
  setTimeout(() => (notif.value = null), 3500)
}

// ---------- Status stok ----------
function statusStok(stok) {
  if (stok <= 0) return 'habis'
  if (stok <= BATAS_MENIPIS) return 'menipis'
  return 'aman'
}
const labelStatus = { aman: 'Aman', menipis: 'Menipis', habis: 'Stok Habis' }

// ---------- Computed: cari -> urut (berantai) ----------
const hasilCari = computed(() => {
  const q = keyword.value.trim().toLowerCase()
  if (!q) return bahanList.value
  return bahanList.value.filter(
    (b) =>
      b.nama_bahan.toLowerCase().includes(q) ||
      b.kategori.toLowerCase().includes(q)
  )
})

const hasilUrut = computed(() => {
  const arah = urutan.value === 'asc' ? 1 : -1
  return [...hasilCari.value].sort(
    (a, b) => arah * a.nama_bahan.localeCompare(b.nama_bahan, 'id')
  )
})

// ---------- Computed: 4 tile ringkasan ----------
const totalBahan = computed(() => bahanList.value.length)

const menipisHabis = computed(
  () => bahanList.value.filter((b) => statusStok(b.stok) !== 'aman').length
)

const jumlahKategori = computed(
  () =>
    bahanList.value
      .map((b) => b.kategori.trim().toLowerCase())
      .filter((k, i, arr) => arr.indexOf(k) === i).length
)

const totalStok = computed(() =>
  bahanList.value.reduce((jumlah, b) => jumlah + b.stok, 0)
)

// ---------- Computed: bar per kategori (CSS murni) ----------
const ringkasanKategori = computed(() => {
  const per = bahanList.value.reduce((acc, b) => {
    acc[b.kategori] = (acc[b.kategori] || 0) + b.stok
    return acc
  }, {})
  const daftar = Object.entries(per)
    .map(([kategori, total]) => ({ kategori, total }))
    .sort((a, b) => b.total - a.total)
  const maks = daftar.reduce((m, d) => Math.max(m, d.total), 0)
  return daftar.map((d) => ({
    ...d,
    lebar: maks > 0 ? Math.max((d.total / maks) * 100, d.total > 0 ? 2 : 0) : 0,
  }))
})

const fmt = (n) => new Intl.NumberFormat('id-ID', { maximumFractionDigits: 2 }).format(n)

// ---------- Aksi ----------
function bukaTambah() {
  editId.value = null
  form.value = formKosong()
  formError.value = ''
  formTerbuka.value = true
}

function bukaEdit(item) {
  editId.value = item.id
  form.value = {
    nama_bahan: item.nama_bahan,
    kategori: item.kategori,
    stok: item.stok,
    satuan: item.satuan,
  }
  formError.value = ''
  formTerbuka.value = true
}

function tutupForm() {
  formTerbuka.value = false
}

async function simpan() {
  formError.value = ''
  const stokAngka = Number(form.value.stok)
  if (
    !form.value.nama_bahan.trim() ||
    !form.value.kategori.trim() ||
    !form.value.satuan.trim()
  ) {
    formError.value = 'Nama bahan, kategori, dan satuan wajib diisi.'
    return
  }
  if (form.value.stok === '' || Number.isNaN(stokAngka) || stokAngka < 0) {
    formError.value = 'Stok harus berupa angka 0 atau lebih.'
    return
  }
  const payload = {
    nama_bahan: form.value.nama_bahan.trim(),
    kategori: form.value.kategori.trim(),
    stok: stokAngka,
    satuan: form.value.satuan.trim(),
  }
  menyimpan.value = true
  try {
    if (editId.value === null) {
      await request(ENDPOINT, { method: 'POST', body: JSON.stringify(payload) })
      tampilNotif('ok', `${payload.nama_bahan} ditambahkan.`)
    } else {
      await request(`${ENDPOINT}/${editId.value}`, {
        method: 'PUT',
        body: JSON.stringify(payload),
      })
      tampilNotif('ok', `${payload.nama_bahan} diperbarui.`)
    }
    formTerbuka.value = false
    await muatData(false)
  } catch (err) {
    formError.value =
      err instanceof TypeError ? 'Tidak bisa terhubung ke backend.' : err.message
  } finally {
    menyimpan.value = false
  }
}

async function hapus(item) {
  if (!window.confirm(`Hapus "${item.nama_bahan}" dari daftar?`)) return
  try {
    await request(`${ENDPOINT}/${item.id}`, { method: 'DELETE' })
    tampilNotif('ok', `${item.nama_bahan} dihapus.`)
    await muatData(false)
  } catch (err) {
    tampilNotif('gagal', `Gagal menghapus: ${err.message}`)
  }
}

onMounted(() => muatData())
</script>

<template>
  <main class="halaman">
    <header class="kepala">
      <div>
        <h1>Stok Dapur</h1>
        <p class="sub">Pantau bahan baku restoran: apa yang aman, apa yang harus segera dibeli.</p>
      </div>
    </header>

    <div v-if="notif" :class="['notif', notif.tipe === 'ok' ? 'notif--ok' : 'notif--gagal']" role="status">
      {{ notif.teks }}
    </div>

    <!-- 4 tile ringkasan -->
    <section class="tile-baris" aria-label="Ringkasan">
      <div class="tile">
        <span class="tile-label">Total Bahan Baku</span>
        <strong class="tile-nilai">{{ fmt(totalBahan) }}</strong>
      </div>
      <div class="tile tile--waspada">
        <span class="tile-label">Stok Menipis + Habis</span>
        <strong class="tile-nilai">{{ fmt(menipisHabis) }}</strong>
      </div>
      <div class="tile">
        <span class="tile-label">Jumlah Kategori</span>
        <strong class="tile-nilai">{{ fmt(jumlahKategori) }}</strong>
      </div>
      <div class="tile">
        <span class="tile-label">Total Satuan Stok</span>
        <strong class="tile-nilai">{{ fmt(totalStok) }}</strong>
      </div>
    </section>

    <!-- Ringkasan stok per kategori -->
    <section v-if="loadState === 'success' && ringkasanKategori.length" class="panel">
      <h2>Ringkasan Stok per Kategori</h2>
      <ul class="bar-daftar">
        <li v-for="k in ringkasanKategori" :key="k.kategori" class="bar-baris">
          <span class="bar-nama">{{ k.kategori }}</span>
          <span class="bar-trek">
            <span class="bar-isi" :style="{ width: k.lebar + '%' }"></span>
          </span>
          <span class="bar-angka">{{ fmt(k.total) }}</span>
        </li>
      </ul>
    </section>

    <!-- Toolbar -->
    <section class="toolbar">
      <input
        v-model="keyword"
        class="input cari"
        type="search"
        placeholder="Cari nama bahan atau kategori"
        aria-label="Cari bahan baku"
      />
      <div class="urut" role="group" aria-label="Urutkan nama bahan">
        <button
          :class="['btn', { 'btn--aktif': urutan === 'asc' }]"
          @click="urutan = 'asc'"
        >A-Z</button>
        <button
          :class="['btn', { 'btn--aktif': urutan === 'desc' }]"
          @click="urutan = 'desc'"
        >Z-A</button>
      </div>
      <button class="btn btn--utama" @click="bukaTambah">Tambah bahan</button>
    </section>

    <!-- Form tambah / edit -->
    <section v-if="formTerbuka" class="panel form-panel">
      <h2>{{ editId === null ? 'Tambah bahan baku' : 'Ubah bahan baku' }}</h2>
      <form class="form-grid" @submit.prevent="simpan" novalidate>
        <label>Nama bahan
          <input v-model="form.nama_bahan" class="input" type="text" placeholder="mis. Bawang Merah" />
        </label>
        <label>Kategori
          <input v-model="form.kategori" class="input" type="text" placeholder="mis. Sayuran" />
        </label>
        <label>Stok
          <input v-model="form.stok" class="input" type="number" min="0" step="any" placeholder="0" />
        </label>
        <label>Satuan
          <input v-model="form.satuan" class="input" type="text" placeholder="kg, liter, butir" />
        </label>
        <p v-if="formError" class="form-error" role="alert">{{ formError }}</p>
        <div class="form-aksi">
          <button type="button" class="btn" @click="tutupForm">Batal</button>
          <button type="submit" class="btn btn--utama" :disabled="menyimpan">
            {{ menyimpan ? 'Menyimpan...' : 'Simpan' }}
          </button>
        </div>
      </form>
    </section>

    <!-- Status data -->
    <section v-if="loadState === 'loading'" class="status">
      <p>Memuat data bahan baku...</p>
    </section>

    <section v-else-if="loadState === 'error'" class="status status--error" role="alert">
      <p>{{ loadError }}</p>
      <button class="btn" @click="muatData()">Coba lagi</button>
    </section>

    <section v-else-if="hasilUrut.length === 0" class="status">
      <p v-if="keyword">Tidak ada bahan yang cocok dengan "{{ keyword }}". Coba kata kunci lain.</p>
      <p v-else>Belum ada bahan baku. Tambahkan bahan pertama dengan tombol di atas.</p>
    </section>

    <!-- Tabel (jadi kartu di layar sempit) -->
    <section v-else class="tabel-bungkus">
      <table class="tabel">
        <thead>
          <tr>
            <th>Nama bahan</th>
            <th>Kategori</th>
            <th class="angka">Stok</th>
            <th>Status</th>
            <th class="aksi-kol">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="b in hasilUrut" :key="b.id">
            <td data-label="Nama bahan" class="nama">{{ b.nama_bahan }}</td>
            <td data-label="Kategori">{{ b.kategori }}</td>
            <td data-label="Stok" class="angka">{{ fmt(b.stok) }} {{ b.satuan }}</td>
            <td data-label="Status">
              <span
                :class="[
                  'badge',
                  {
                    'badge--aman': statusStok(b.stok) === 'aman',
                    'badge--menipis': statusStok(b.stok) === 'menipis',
                    'badge--habis': statusStok(b.stok) === 'habis',
                  },
                ]"
              >{{ labelStatus[statusStok(b.stok)] }}</span>
            </td>
            <td class="aksi-kol">
              <button class="btn btn--kecil" @click="bukaEdit(b)">Edit</button>
              <button class="btn btn--kecil btn--bahaya" @click="hapus(b)">Hapus</button>
            </td>
          </tr>
        </tbody>
      </table>
    </section>
  </main>
</template>
