# Stok Dapur: Mini Dashboard Bahan Baku Restoran

Tugas Mini Project Web Application Development (Soal A).
Frontend: Vue 3 (Composition API) + Vite. Backend: FastAPI. Data disimpan di file JSON lokal (tanpa database).

## Struktur
```
backend/    FastAPI, data.json (seed 26 bahan baku), requirements.txt
frontend/   Vue 3 + Vite
```

## Menjalankan backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```
Dokumentasi OpenAPI: http://localhost:8000/docs

## Menjalankan frontend
```bash
cd frontend
npm install
npm run dev
```
Buka http://localhost:5173. Jika backend tidak di `localhost:8000`, buat `frontend/.env` berisi
`VITE_API_URL=http://alamat-backend:port`.

## Endpoint
| Method | Path | Fungsi |
|---|---|---|
| GET | /bahan-baku | Ambil semua data |
| GET | /bahan-baku/{id} | Ambil satu data |
| POST | /bahan-baku | Tambah data |
| PUT | /bahan-baku/{id} | Ubah seluruh data |
| PATCH | /bahan-baku/{id} | Ubah sebagian data (mis. stok) |
| DELETE | /bahan-baku/{id} | Hapus data |

Setiap tambah/ubah/hapus menimpa ulang `backend/data.json`, sehingga data tetap ada setelah server restart.

## Ambang batas status stok
| Status | Kondisi |
|---|---|
| Stok Habis | stok = 0 |
| Menipis | 0 < stok <= 5 |
| Aman | stok > 5 |

Ambang 5 dipilih karena sebagian besar bahan dihitung dalam kg/liter dan stok di bawah 5 sudah
berisiko habis dalam sehari-dua hari operasional. Nilainya ada di konstanta `BATAS_MENIPIS` pada
`frontend/src/App.vue`.

## Fitur
- Cari berdasarkan nama bahan atau kategori (`computed` + `.filter()`)
- Urut A-Z / Z-A berdasarkan nama bahan (`computed` berantai + `.sort()`)
- 4 tile ringkasan dihitung dengan `computed` (`.filter()`, `.map()`, `.reduce()`)
- Bar "Ringkasan Stok per Kategori" dengan CSS murni (lebar dari `computed`)
- Tambah, edit, dan hapus data langsung ke backend
- Status UI: loading, kosong, error (dengan tombol coba lagi), dan berhasil
- Responsif: desktop >= 1024px, tablet 768-1023px, mobile < 768px (tabel menjadi kartu)
